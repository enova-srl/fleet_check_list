# -*- coding: utf-8 -*-

from odoo import models, fields, api

class TaskChecklist(models.Model):
    _name = 'checklist.vehicular'
    _description = 'Checklist for the fleet'

    name = fields.Char(string='Name', required=True)
    description = fields.Char(string='Description')
