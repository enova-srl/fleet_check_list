# -*- coding: utf-8 -*-
from odoo import models, fields, api

class TaskChecklist(models.Model):
    _name = 'checklist.vehicular'
    _description = 'Checklist for the fleet'
    _inherit = ["mail.thread", "mail.activity.mixin"]

    name = fields.Char(string='Nombre')
    attachment_ids = fields.Many2many(comodel_name='ir.attachment', relation='attachments_rel', string='Adjuntar Archivo')
    number_id = fields.Char(string="ID", readonly=True, required=True, copy=False, default='Nuevo')
    description = fields.Char(string='Description')
    inspected_by = fields.Many2one('res.partner', string='Inspeccionado por')
    revisor_by = fields.Many2one('res.partner', string='Revisado por')
    vehicle_id = fields.Many2one('fleet.vehicle', string='Movil')
    date_inspected = fields.Datetime(string='Fecha', required=True, default=fields.Datetime.now)
    odometro = fields.Char(string='Kilometros', required=True)

    nivel_aceite = fields.Selection(selection=[("bueno", "Bueno"), ("regular", "Regular"), ("malo", "Malo")])
    nivel_agua = fields.Selection(selection=[("bueno", "Bueno"), ("regular", "Regular"), ("malo", "Malo")])
    luces = fields.Selection(selection=[("bueno", "Bueno"), ("regular", "Regular"), ("malo", "Malo")])
    parabrisas = fields.Selection(selection=[("bueno", "Bueno"), ("regular", "Regular"), ("malo", "Malo")])
    nivel_de_combustible = fields.Selection(selection=[("1/4 tanque", "1/4 Tanque"), ("1/2 tanque", "1/2 Tanque"), ("3/4 tanque", "3/4 Tanque"), ("tanque lleno", "Tanque Lleno")])
    liquido_freno = fields.Selection(selection=[("bueno", "Bueno"), ("regular", "Regular"), ("malo", "Malo")])
    neumaticos = fields.Selection(selection=[("bueno", "Bueno"), ("regular", "Regular"), ("malo", "Malo")])
    matafuegos = fields.Selection(selection=[("bueno", "Bueno"), ("regular", "Regular"), ("malo", "Malo")])
    bateria = fields.Selection(selection=[("bueno", "Bueno"), ("regular", "Regular"), ("malo", "Malo")])
    precinto_matafuego = fields.Selection(selection=[("si", "SI"), ("no", "NO")])

    observaciones = fields.Char(required=True)

    state = fields.Selection([('cargado', 'Cargado'), ('revisado', 'Revisado')],
                             string='Status',
                             copy=False,
                             index=True,
                             readonly=True,
                             track_visibility="onchange",
                             default='cargado')


    def button_revisado(self):
        return self.write({"state": "revisado"})

    def button_cargado(self):
        return self.write({"state": "cargado", "result": "todo"})

    @api.model
    def create(self, vals):
        if vals.get('number_id', 'Nuevo') == 'Nuevo':
            vals['number_id'] = self.env['ir.sequence'].next_by_code(
                'checklist.vehicular') or 'Nuevo'
        result = super(TaskChecklist, self).create(vals)
        return result


