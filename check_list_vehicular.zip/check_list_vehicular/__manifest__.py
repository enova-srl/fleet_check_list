# -*- coding: utf-8 -*-
###################################################################################
#    Impulso
#    Copyright (C) 2021-TODAY Impulso.
#
#    This program is free software: you can modify
#    it under the terms of the GNU Affero General Public License (AGPL) as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
###################################################################################
{
    'name': 'Check List Vehicular',
    'version': '13.0',
    'description': """Evaluate task completion on the basis of checklists""",
    'category': 'Fleet',
    'author': 'Marcos Kittlein',
    'company': 'Impulso',
    'maintainer': 'Impulso',
    'website': 'http://impulso-sas.com.ar',
    'depends': ['fleet'],
    'data': [
        'views/project_task_view.xml',
        'data/sequence.xml',
    ],
    'images': ['static/description/banner.jpg'],
    'license': 'AGPL-3',
    'installable': True,
    'auto_install': False,
    'application': False,
}
